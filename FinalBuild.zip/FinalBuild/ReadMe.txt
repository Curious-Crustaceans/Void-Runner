Controls: Keyboard or Xbox One Controller

Move: WASD, Left Stick
Shoot: Arrow Keys, Right Stick
Void Shift: Space or RT